
public class Course {
	private String name;
	private String instructor;
	private String room;
	
	public Course(){
		this.name = null;
		this.instructor = null;
		this.room = null;
	}

	public Course(String name){
		this.name = name;
		this.instructor = null;
		this.room = null;
	}
	
	public Course(String name, String instructor){
		this.name = name;
		this.instructor = instructor;
		this.room = null;
	}
	
	public Course(String name, String instructor, String room){
		this.name = name;
		this.instructor = instructor;
		this.room = room;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getInstructor() {
		return this.instructor;
	}
	
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	
	public String getRoom() {
		return this.room;
	}
	
	public void setRoom(String room) {
		this.room = room;
	}
	
	public static boolean equals(Course a, Course b) {
		if(a.getName().equals(b.getName()) && a.getInstructor().equals(b.getInstructor()) && a.getRoom().equals(b.getRoom())) return true;
		else return false;
	}
	
	public String toString() {
		return "["+this.name+"] (["+this.instructor+"]) - #["+this.room+"]";
	}
	
	public static boolean isDuplicatedCourse(Course newC, Course takingC) {
		if(newC.getName().equals(takingC.getName()) && newC.getInstructor().equals(takingC.getInstructor()) && newC.getRoom().equals(takingC.getRoom())) return false;
		return true;
	}
}
