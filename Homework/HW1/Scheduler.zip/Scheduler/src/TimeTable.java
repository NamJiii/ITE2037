
public class TimeTable {
	private String day;
	Course times[] = new Course[10];
	
	public TimeTable() {
		day = null;
		for(int i=0; i<10;i++) times[i] = new Course();
	}
	
	public String getDay() {
		return this.day;
	}
	
	public void setDay(String day) {
		this.day = day;
	}
	
	public int setTimes(int index, Course newC) {
		int returnNum;
		if(times[index].getName()==null && times[index].getInstructor()==null && times[index].getRoom() ==null) returnNum=1;
		else if(times[index].getName().equals(newC.getName())&&times[index].getInstructor().equals(newC.getInstructor())&&times[index].getRoom().equals(newC.getRoom())) return 0;
		else returnNum=-1;
		
		this.times[index] = newC;
		
		return returnNum;
	}
	
	public Course getTimes(int index) {
		return this.times[index];
	}
	
	public Course[] getAllTimes() {
		return this.times;
	}
	
	public boolean isEmptyTime(int index) {
		if(this.times[index].getName()==null&&this.times[index].getInstructor()==null&&this.times[index].getRoom()==null) return true;
		else return false;
	}
}
